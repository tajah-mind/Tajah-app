from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class Message(BaseModel):
    text: str

@app.get("/")
def home():
    return {"message": "Tajah backend is running!"}

@app.post("/message")
def message_endpoint(msg: Message):
    reply = f"I heard you say: '{msg.text}'. Tajah is learning fast!"
    return {"reply": reply}
